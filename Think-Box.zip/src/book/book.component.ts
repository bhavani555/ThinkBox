import { Component } from '@angular/core';
import { IBook } from "./book";

@Component({
  selector: 'bk',
  templateUrl: './book.component.html',
  //styleUrls: ['./form.component.css'],
  //styleUrls: ['./app.component.css']
})
export class BookComponent {

  Title:string="bubblegums and candies";
   imgWidth:number=800;
  imgHeight:number=180;

      books:IBook[]=[
  
   {id:1,Title:"bubblegums and candies", catagory:"Fiction",Author:"Preeti Shenoy",  bookImg:
   "./assets/image/pr.jpg"},
   {id:2,Title:"4th of July", catagory:"Fiction",Author:"James Patterson",bookImg:"./assets/image/pa.jpg"},
  
   //{id:3,Title:"A Case of Need", catagory:"fiction",Author:"Michael Crichton", bookImg:"5"},
   //{id:4,Title:"A Far Horizon", catagory:"Fiction",Author:"Meira chand", bookImg:"5"},
   {id:5,Title:"A prisoner of birth", catagory:"Fiction",Author:"Jeffrey Archer", bookImg:"./assets/image/pb.jpg"},
   {id:6,Title:"A Fine Family", catagory:"Fiction",Author:"Gurucharan Das",  bookImg:"./assets/image/ff.jpg"},
   
   
 
  
 ];

}
