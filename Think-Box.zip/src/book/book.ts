export interface IBook{

    id:number;
    Title:string;
    catagory:string;
    Author:string;
    bookImg:string;
    
}