import { Component } from '@angular/core';
import { IStory } from "./story";

@Component({
  selector: 'st',
  templateUrl: './story.component.html',
  //styleUrls: ['./form.component.css'],
  //styleUrls: ['./app.component.css']
})
export class StoryComponent{

  Title:string="bubblegums and candies";
   imgWidth:number=800;
  imgHeight:number=180;

      story:IStory[]=[
  
   {id:1,Title:"A Piece of Cake", catagory:"Story",Author:"Jill Murphy",  bookImg:
   "./assets/image/ck.jpg"},
   {id:2,Title:"A wish for christmas", catagory:"Story",Author:"Gaby Goldsack",bookImg:"./assets/image/ch.jpg"},
  
   //{id:3,Title:"A Case of Need", catagory:"fiction",Author:"Michael Crichton", bookImg:"5"},
   //{id:4,Title:"A Far Horizon", catagory:"Fiction",Author:"Meira chand", bookImg:"5"},
   {id:3,Title:"A Quiet Night In	", catagory:"Story",Author:"Jill Murphy", bookImg:"./assets/image/nt.jpg"},
   {id:4,Title:"A Dollar for Penny lvl2", catagory:"Story",Author:"Dr.Julie Glass",  bookImg:"./assets/image/st.jpg"},
   
   
 
  
 ];

}
