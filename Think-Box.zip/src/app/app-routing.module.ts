import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LibraryComponent } from './../library/library.component';
import { CollectionComponent } from './../collection/collection.component';
import { FormComponent } from './../form/form.component';
import { BookComponent } from './../book/book.component';
import { bookDetailComponent } from "../bookDetail/bookDetail.component";
import { AboutComponent } from "../contactus/about.component";
import { ErrorComponent } from "../error/error.component";
import { StoryComponent } from "../story/story.component";


const routes: Routes = [

    {path:'library',component:LibraryComponent},
  //{path:'movies',component:MovieComponent},
//{path:'',component:HomeComponent,pathMatch:'full'},
 // {path:'home',component:HomeComponent},
  {path:'collection',component:CollectionComponent},
  {path:'form',component:FormComponent},
  { path:'book',component:BookComponent},
  {path:'book/:id',component:bookDetailComponent},
    { path:'about',component:AboutComponent},
    { path:'story',component:StoryComponent},
   
  { path: '**',  component:ErrorComponent },

 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
